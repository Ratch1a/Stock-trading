#!/bin/bash
python ai_stock_trading_bot.py
